// GC Protect V2 Popup

const SEV_COLORS = { critical:'#FF453A', high:'#FF9F0A', medium:'#FFD60A', low:'#30D158' };

async function load() {
  try {
    const data = await chrome.storage.local.get(['auditLog','gcEnabled','customEntities']);
    const log = data.auditLog || [];
    const enabled = data.gcEnabled !== false;
    const customs = data.customEntities || [];

    // Toggle state
    document.getElementById('gcToggle').checked = enabled;
    updateToggleUI(enabled);

    // Stats
    const protected_entries = log.filter(e => e.action === 'protected');
    const unprotected = log.filter(e => e.action === 'sent_unprotected').length;
    const totalEntities = protected_entries.reduce((s,e) => s + (e.tokensCreated||0), 0);
    const critical = protected_entries.filter(e => e.riskLevel === 'critical').length;

    document.getElementById('valProtected').textContent = protected_entries.length;
    document.getElementById('valEntities').textContent = totalEntities;
    document.getElementById('valCritical').textContent = critical;
    document.getElementById('valUnprotected').textContent = unprotected;

    // Status pill
    const pill = document.getElementById('statusPill');
    if (!enabled) {
      pill.textContent = 'PAUSED';
      pill.style.background = 'rgba(255,159,10,0.15)';
      pill.style.color = '#FF9F0A';
      pill.style.borderColor = 'rgba(255,159,10,0.3)';
    } else if (protected_entries.length > 0) {
      pill.textContent = 'ACTIVE';
      pill.style.background = 'rgba(48,209,88,0.15)';
      pill.style.color = '#30D158';
      pill.style.borderColor = 'rgba(48,209,88,0.3)';
    }

    // Platform detection
    const [tab] = await chrome.tabs.query({ active:true, currentWindow:true });
    const url = tab?.url || '';
    const platforms = {
      'chatgpt.com':'ChatGPT', 'openai.com':'ChatGPT',
      'claude.ai':'Claude', 'gemini.google.com':'Gemini',
      'copilot.microsoft.com':'Copilot', 'deepseek.com':'DeepSeek',
      'perplexity.ai':'Perplexity', 'grok.com':'Grok',
    };
    const match = Object.entries(platforms).find(([host]) => url.includes(host));
    const platformText = document.getElementById('platformText');
    if (match) {
      platformText.textContent = `Active on ${match[1]}`;
      platformText.style.color = '#30D158';
    }

    // Custom entities list
    renderCustomList(customs);

    // Log
    const logList = document.getElementById('logList');
    if (log.length === 0) {
      logList.innerHTML = '<div class="empty">No activity yet.<br>Open an AI tool to get started.</div>';
      return;
    }
    logList.innerHTML = log.slice(0,12).map(e => {
      const time = new Date(e.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
      const color = SEV_COLORS[e.riskLevel] || '#666';

      // Safety flags get special treatment
      if (e.safetyFlag) {
        return `<div class="log-item" style="background:rgba(255,69,58,0.08);border-left:3px solid #FF453A;padding-left:13px;">
          <span style="font-size:14px">🚩</span>
          <div style="flex:1">
            <div style="color:#FF6B6B;font-size:12px;font-weight:600">Safety Flag — ${e.safetyLabel || 'Content flagged'}</div>
            <div style="color:rgba(255,255,255,0.35);font-size:10px">${e.platform} · ${time}</div>
          </div>
        </div>`;
      }

      const icon = e.action === 'protected' ? '🛡' : e.action === 'sent_unprotected' ? '⚠️' : '•';
      return `<div class="log-item">
        <div class="log-dot" style="background:${color}"></div>
        <span style="flex:1;color:rgba(255,255,255,0.8)">${icon} ${e.platform}</span>
        <span style="color:rgba(255,255,255,0.4);font-size:11px">${e.riskScore}/100</span>
        <span style="color:rgba(255,255,255,0.25);font-size:10px;margin-left:6px">${time}</span>
      </div>`;
    }).join('');

  } catch(err) {
    console.error('GC Protect popup error:', err);
  }
}

function updateToggleUI(enabled) {
  const sub = document.getElementById('toggleSub');
  const stats = document.getElementById('statsSection');
  sub.textContent = enabled ? 'Intercepting AI prompts' : 'Protection paused — prompts go through unprotected';
  sub.style.color = enabled ? 'rgba(255,255,255,0.4)' : '#FF9F0A';
}

window.toggleProtection = async function(enabled) {
  await chrome.storage.local.set({ gcEnabled: enabled });
  updateToggleUI(enabled);

  const pill = document.getElementById('statusPill');
  if (enabled) {
    pill.textContent = 'ACTIVE';
    pill.style.background = 'rgba(48,209,88,0.15)';
    pill.style.color = '#30D158';
    pill.style.borderColor = 'rgba(48,209,88,0.3)';
  } else {
    pill.textContent = 'PAUSED';
    pill.style.background = 'rgba(255,159,10,0.15)';
    pill.style.color = '#FF9F0A';
    pill.style.borderColor = 'rgba(255,159,10,0.3)';
  }
};

function renderCustomList(customs) {
  const list = document.getElementById('customList');
  if (!customs.length) {
    list.innerHTML = '<div class="empty">No custom patterns yet.<br>Add your company\'s sensitive ID formats below.</div>';
    return;
  }
  list.innerHTML = customs.map((c,i) => `
    <div class="custom-row">
      <span class="custom-badge">CUSTOM</span>
      <span style="flex:1;color:rgba(255,255,255,0.8)">${c.name}</span>
      <span style="color:rgba(255,255,255,0.4);font-family:monospace;font-size:11px">${c.pattern}</span>
      <button onclick="removeCustom(${i})" style="background:none;border:none;color:rgba(255,69,58,0.6);cursor:pointer;font-size:14px;padding:0 0 0 8px">✕</button>
    </div>`).join('');
}

window.addCustom = async function() {
  const name = document.getElementById('customName').value.trim();
  const pattern = document.getElementById('customPattern').value.trim();
  if (!name || !pattern) return;

  // Validate regex
  try { new RegExp(pattern); } catch(e) { alert('Invalid pattern: ' + e.message); return; }

  const data = await chrome.storage.local.get('customEntities');
  const customs = data.customEntities || [];
  customs.push({ name, pattern, severity: 'high' });
  await chrome.storage.local.set({ customEntities: customs });

  document.getElementById('customName').value = '';
  document.getElementById('customPattern').value = '';
  renderCustomList(customs);
};

window.removeCustom = async function(index) {
  const data = await chrome.storage.local.get('customEntities');
  const customs = data.customEntities || [];
  customs.splice(index, 1);
  await chrome.storage.local.set({ customEntities: customs });
  renderCustomList(customs);
};

window.clearAll = async function() {
  if (!confirm('Clear all logs and session data?')) return;
  await chrome.storage.local.set({ auditLog:[], sessionVault:{} });
  load();
};

window.exportLog = async function() {
  const data = await chrome.storage.local.get('auditLog');
  const log = data.auditLog || [];
  if (!log.length) { alert('No activity to export yet.'); return; }
  const csv = [
    'Date,Time,Platform,Risk Score,Risk Level,Action,Fields Protected,Data Types',
    ...log.map(e => [
      new Date(e.timestamp).toLocaleDateString(),
      new Date(e.timestamp).toLocaleTimeString(),
      e.platform, e.riskScore, e.riskLevel,
      e.action, e.tokensCreated||0,
      (e.entityTypes||[]).join('|'),
    ].join(','))
  ].join('\n');
  const blob = new Blob([csv], { type:'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gc-protect-log-${new Date().toISOString().split('T')[0]}.csv`;
  a.click();
};

load();
