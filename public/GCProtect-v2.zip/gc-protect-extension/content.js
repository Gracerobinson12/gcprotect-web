(() => {
  // ── Safe chrome wrappers ──
  function safeSend(payload) {
    try {
      if (typeof chrome === 'undefined') return;
      if (!chrome.runtime) return;
      if (!chrome.runtime.id) return;
      const msg = chrome.runtime.sendMessage({ type: 'LOG_INTERACTION', payload });
      if (msg && typeof msg.catch === 'function') msg.catch(() => {});
    } catch (e) {}
  }

  function sendAdminAlert(failures) {
    try {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.id) return;
      chrome.runtime.sendMessage({
        type: 'ADMIN_ALERT',
        payload: {
          platform: getPlatform(),
          failures: failures,
          url: window.location.href,
          userAgent: navigator.userAgent,
        }
      });
    } catch(e) {}
  }

  function safeGet(keys, cb) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage) { cb({}); return; }
      chrome.storage.local.get(keys, cb);
    } catch (e) { cb({}); }
  }

  function safeSet(data) {
    try {
      if (typeof chrome === 'undefined' || !chrome.storage) return;
      chrome.storage.local.set(data);
    } catch (e) {}
  }

  // ── State ──
  let protectionEnabled = true;
  let overlayOpen = false;
  let ignoredText = '';

  // ── REMOTE SELECTORS (loaded from config) ──
  let REMOTE_SELECTORS = null;

  // ── Load settings ──
  safeGet(['gcEnabled', 'sessionVault', 'customEntities', 'remoteConfig'], (data) => {
    protectionEnabled = data.gcEnabled !== false;
    if (data.sessionVault) {
      for (const [t, v] of Object.entries(data.sessionVault)) {
        SESSION_VAULT.set(t, v);
        USED_TOKENS.add(t);
      }
    }
    if (data.customEntities) loadCustomEntities(data.customEntities);
    if (data.remoteConfig && data.remoteConfig.selectors) {
      REMOTE_SELECTORS = data.remoteConfig.selectors;
      console.log('[GC Protect] Loaded remote selectors for platforms:', Object.keys(REMOTE_SELECTORS));
    }
  });

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes) => {
        if (changes.gcEnabled) {
          protectionEnabled = changes.gcEnabled.newValue !== false;
          showToast(protectionEnabled ? '🛡 GC Protect ON' : '⏸ GC Protect OFF', protectionEnabled ? '#30D158' : '#FF9F0A');
        }
        if (changes.customEntities) loadCustomEntities(changes.customEntities.newValue || []);
        if (changes.remoteConfig) {
          const newConfig = changes.remoteConfig.newValue;
          if (newConfig && newConfig.selectors) {
            REMOTE_SELECTORS = newConfig.selectors;
            console.log('[GC Protect] Remote selectors updated dynamically');
          }
        }
      });
    }
  } catch (e) {}

  // ── Platform ──
  function getPlatform() {
    const h = window.location.hostname;
    if (h.includes('chatgpt.com') || h.includes('openai.com')) return 'chatgpt';
    if (h.includes('claude.ai')) return 'claude';
    if (h.includes('gemini.google.com')) return 'gemini';
    if (h.includes('copilot.microsoft.com')) return 'copilot';
    if (h.includes('deepseek.com')) return 'deepseek';
    if (h.includes('perplexity.ai')) return 'perplexity';
    if (h.includes('grok.com')) return 'grok';
    if (h.includes('poe.com')) return 'poe';
    return 'unknown';
  }

  function getPlatformDisplay() {
    const p = getPlatform();
    const map = {
      chatgpt: 'ChatGPT', claude: 'Claude', gemini: 'Gemini',
      copilot: 'Copilot', deepseek: 'DeepSeek', perplexity: 'Perplexity',
      grok: 'Grok', poe: 'Poe'
    };
    return map[p] || 'AI Tool';
  }

  // ── Session vault ──
  const SESSION_VAULT = new Map();
  const USED_TOKENS = new Set();

  function storeTokens(tokenMap) {
    for (const [token, original] of Object.entries(tokenMap)) {
      SESSION_VAULT.set(token, original);
    }
    safeSet({ sessionVault: Object.fromEntries(SESSION_VAULT) });
  }

  window.addEventListener('beforeunload', () => {
    try {
      if (chrome?.storage) chrome.storage.local.remove('sessionVault');
    } catch(e) {}
    SESSION_VAULT.clear();
    USED_TOKENS.clear();
  });

  // ── Custom entities ──
  let CUSTOM_PATTERNS = [];
  function loadCustomEntities(entities) {
    CUSTOM_PATTERNS = (entities || []).map(e => ({
      type: 'CUSTOM_' + e.name.toUpperCase().replace(/\s/g, '_'),
      label: e.name,
      regex: new RegExp(e.pattern, 'g'),
      severity: e.severity || 'high',
      custom: true,
    }));
  }

  // ── HARDCODED FALLBACK SELECTORS ──
  const DEFAULT_PROMPT_SELECTORS = [
    '#prompt-textarea',
    'div[contenteditable="true"][aria-label="Message ChatGPT"]',
    'div[contenteditable="true"][data-lexical-editor]',
    'div[contenteditable="true"][aria-multiline="true"]',
    'div[contenteditable="true"]',
    'textarea[placeholder]',
    'textarea',
  ];
  const DEFAULT_SEND_SELECTORS = [
    'button[data-testid="send-button"]',
    'button[aria-label="Send message"]',
    'button[aria-label="Send prompt"]',
    'button[aria-label="Send Message"]',
    'button[aria-label="Submit message"]',
    'button[aria-label="Submit"]',
  ];

  // ── Get prompt box (remote config first) ──
  function getBox() {
    const platform = getPlatform();
    let selectors = DEFAULT_PROMPT_SELECTORS;

    if (REMOTE_SELECTORS && REMOTE_SELECTORS[platform] && REMOTE_SELECTORS[platform].prompt_box) {
      selectors = REMOTE_SELECTORS[platform].prompt_box;
    }

    for (const s of selectors) {
      try {
        const el = document.querySelector(s);
        if (el && el.offsetParent !== null) return el;
      } catch(e) { /* skip invalid selector */ }
    }
    return null;
  }

  function getText(box) {
    if (!box) return '';
    if (box.tagName === 'TEXTAREA') return box.value;
    return box.innerText || box.textContent || '';
  }

  function setText(box, text) {
    if (!box) return;
    if (box.tagName === 'TEXTAREA') {
      const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
      setter?.call(box, text);
    } else {
      box.innerText = text;
    }
    ['input', 'change'].forEach(evt => box.dispatchEvent(new Event(evt, { bubbles: true })));
    box.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText' }));
  }

  // ── Click send (remote config first) ──
  function clickSend() {
    const platform = getPlatform();
    let selectors = DEFAULT_SEND_SELECTORS;

    if (REMOTE_SELECTORS && REMOTE_SELECTORS[platform] && REMOTE_SELECTORS[platform].send_button) {
      selectors = REMOTE_SELECTORS[platform].send_button;
    }

    let attempts = 0;
    function try_click() {
      attempts++;
      for (const s of selectors) {
        try {
          const btn = document.querySelector(s);
          if (btn && !btn.disabled && btn.offsetParent !== null) {
            btn.click();
            return true;
          }
        } catch(e) { /* skip */ }
      }
      for (const btn of document.querySelectorAll('button')) {
        if (btn.disabled || btn.offsetParent === null) continue;
        const label = (btn.getAttribute('aria-label') || '').toLowerCase();
        const testid = (btn.getAttribute('data-testid') || '').toLowerCase();
        if (label.includes('send') || testid.includes('send')) {
          btn.click();
          return true;
        }
      }
      return false;
    }

    const intervals = [100, 250, 500, 800, 1200];
    let i = 0;
    function next() {
      if (i >= intervals.length) return;
      setTimeout(() => {
        if (!try_click()) { i++; next(); }
      }, intervals[i++]);
    }
    next();
  }

  // ── Scanner ──
  const BUILT_IN_PATTERNS = [
    { type: 'GITHUB_TOKEN', label: 'GitHub Token', regex: /\b(ghp|gho|ghs|ghr|github_pat)_[A-Za-z0-9_]{20,}\b/g, severity: 'critical' },
    { type: 'AWS_KEY', label: 'AWS Access Key', regex: /\b(AKIA|ASIA|AROA)[A-Z0-9]{16}\b/g, severity: 'critical' },
    { type: 'STRIPE_KEY', label: 'Stripe API Key', regex: /\b(sk|pk|rk)_(live|test)_[A-Za-z0-9]{20,}\b/g, severity: 'critical' },
    { type: 'JWT', label: 'JWT Token', regex: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, severity: 'critical' },
    { type: 'DB_CONNECTION', label: 'Database Connection', regex: /\b(postgres|mongodb|mysql|redis):\/\/[^\s"'<>]{10,}/gi, severity: 'critical' },
    { type: 'SSN', label: 'Social Security Number', regex: /\b\d{3}-\d{2}-\d{4}\b/g, severity: 'critical' },
    { type: 'CREDIT_CARD', label: 'Credit Card', regex: /\b(?:\d{4}[\s\-]?){3}\d{4}\b/g, severity: 'critical' },
    { type: 'API_KEY', label: 'API Key / Secret', regex: /(?:api[_-]?key|secret[_-]?key|access[_-]?token|auth[_-]?token)\s*[:=]\s*['"]?[A-Za-z0-9_\-\.]{20,}['"]?/gi, severity: 'critical' },
    { type: 'PASSWORD', label: 'Password', regex: /(?:password|passwd|pwd)\s*[:=]\s*\S{6,}/gi, severity: 'critical' },
    { type: 'EMAIL', label: 'Email Address', regex: /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g, severity: 'high' },
    { type: 'PHONE', label: 'Phone Number', regex: /\b(?:\+?1[\s.\-]?)?\(?\d{3}\)?[\s.\-]\d{3}[\s.\-]\d{4}\b/g, severity: 'high' },
    { type: 'SALARY', label: 'Salary / Payroll', regex: /\$\s*\d{1,3}(?:,\d{3})*(?:\.\d{2})?/g, severity: 'medium' },
  ];

  const TOKEN_PREFIX = {
    GITHUB_TOKEN:'GC-GH', AWS_KEY:'GC-AWS', STRIPE_KEY:'GC-STR',
    JWT:'GC-JWT', DB_CONNECTION:'GC-DB', SSN:'GC-ID',
    CREDIT_CARD:'GC-CC', API_KEY:'GC-API', PASSWORD:'GC-SEC',
    EMAIL:'GC-EM', PHONE:'GC-PH', SALARY:'GC-SAL', NAME:'GC-C',
  };

  const NAME_EXCLUDE = new Set([
    'ChatGPT','Google','Microsoft','OpenAI','Claude','Gemini','DeepSeek',
    'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
    'January','February','March','April','May','June','July','August',
    'September','October','November','December',
    'Dear','Hello','Hi','Hey','Thank','Please','Best','Kind','Regards',
  ]);

  function genToken(type) {
    const prefix = TOKEN_PREFIX[type] || 'GC-X';
    const array = new Uint8Array(6);
    crypto.getRandomValues(array);
    const random = Array.from(array)
      .map(b => b.toString(36).padStart(2,'0'))
      .join('')
      .toUpperCase()
      .substring(0, 8);
    return prefix + random;
  }

  function uniqueToken(type) {
    let token;
    let attempts = 0;
    do {
      token = genToken(type);
      attempts++;
      if (attempts > 100) break;
    } while (USED_TOKENS.has(token));
    USED_TOKENS.add(token);
    return token;
  }

  function scanText(text) {
    const entities = [];
    const tokenMap = {};
    const allPatterns = [...BUILT_IN_PATTERNS, ...CUSTOM_PATTERNS];

    for (const pattern of allPatterns) {
      const regex = new RegExp(pattern.regex.source, pattern.regex.flags);
      let match;
      while ((match = regex.exec(text)) !== null) {
        const token = uniqueToken(pattern.type);
        entities.push({
          type: pattern.type, label: pattern.label,
          value: match[0], token,
          start: match.index, end: match.index + match[0].length,
          severity: pattern.severity, custom: pattern.custom || false,
        });
        tokenMap[token] = match[0];
      }
    }

    const nameTokenMap = new Map();
    const nameRegex = /\b([A-Z][a-z]{1,20})\s+([A-Z][a-z]{1,20})\b/g;
    let nm;
    while ((nm = nameRegex.exec(text)) !== null) {
      if (!NAME_EXCLUDE.has(nm[1]) && !NAME_EXCLUDE.has(nm[2])) {
        let token = nameTokenMap.get(nm[0]);
        if (!token) {
          token = uniqueToken('NAME');
          nameTokenMap.set(nm[0], token);
        }
        entities.push({
          type: 'NAME', label: 'Person Name', value: nm[0], token,
          start: nm.index, end: nm.index + nm[0].length, severity: 'high',
        });
        tokenMap[token] = nm[0];
      }
    }

    const sorted = [...entities].sort((a, b) => b.start - a.start);
    let protected_text = text;
    for (const e of sorted) {
      protected_text = protected_text.slice(0, e.start) + e.token + protected_text.slice(e.end);
    }

    let score = 0;
    for (const e of entities) score += e.severity === 'critical' ? 30 : e.severity === 'high' ? 15 : 8;

    return { original: text, protected: protected_text, entities, riskScore: Math.min(score, 100), tokenMap };
  }

  // ── Toast ──
  function showToast(message, color = '#0A84FF') {
    document.getElementById('gc-toast')?.remove();
    const toast = document.createElement('div');
    toast.id = 'gc-toast';
    toast.style.cssText = `position:fixed;bottom:20px;left:50%;transform:translateX(-50%);z-index:2147483647;background:rgba(28,28,30,0.95);border:1px solid ${color}60;color:${color};padding:10px 20px;border-radius:20px;font-size:13px;font-weight:600;font-family:-apple-system,sans-serif;backdrop-filter:blur(20px);box-shadow:0 8px 32px rgba(0,0,0,0.4);pointer-events:none;`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  // ── FIXED Response restoration (global walker) ──
  function watchForResponses() {
    if (SESSION_VAULT.size === 0) return null;

    function restoreAllNewNodes() {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      const nodes = [];
      let node;
      while ((node = walker.nextNode())) nodes.push(node);
      let count = 0;
      for (const textNode of nodes) {
        let text = textNode.textContent;
        let changed = false;
        for (const [token, original] of SESSION_VAULT.entries()) {
          if (text.includes(token)) {
            text = text.split(token).join(original);
            changed = true;
            count++;
          }
        }
        if (changed) textNode.textContent = text;
      }
      return count;
    }

    // Run once immediately on existing content
    setTimeout(() => {
      const count = restoreAllNewNodes();
      if (count > 0) showToast(`🛡 Restored ${count} field${count !== 1 ? 's' : ''}`, '#30D158');
    }, 1500);

    // Then observe new mutations
    const obs = new MutationObserver(() => {
      const count = restoreAllNewNodes();
      if (count > 0) showToast(`🛡 Restored ${count} field${count !== 1 ? 's' : ''}`, '#30D158');
    });

    obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    return obs;
  }

  // ── Close overlay ──
  function closeOverlay() {
    document.getElementById('gc-shield-overlay')?.remove();
    overlayOpen = false;
  }

  // ── Overlay ──
  const RISK_COLOR = { critical:'#FF453A', high:'#FF9F0A', medium:'#FFD60A', low:'#30D158' };

  function showOverlay(result, box) {
    closeOverlay();
    overlayOpen = true;

    const color = result.riskScore >= 70 ? '#FF453A' : result.riskScore >= 40 ? '#FF9F0A' : '#FFD60A';
    const grouped = {};
    for (const e of result.entities) {
      if (!grouped[e.label]) grouped[e.label] = { count: 0, sev: e.severity, custom: e.custom };
      grouped[e.label].count++;
    }

    const rows = Object.entries(grouped)
      .sort((a, b) => ({ critical:0, high:1, medium:2, low:3 }[a[1].sev] - { critical:0, high:1, medium:2, low:3 }[b[1].sev]))
      .map(([label, { count, sev, custom }]) => {
        const c = RISK_COLOR[sev] || '#888';
        const icon = sev === 'critical' ? '🔴' : sev === 'high' ? '🟠' : '🟡';
        const badge = custom ? '<span style="font-size:9px;background:rgba(10,132,255,0.2);color:#0A84FF;padding:1px 5px;border-radius:6px;margin-left:4px">CUSTOM</span>' : '';
        return `<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.06);font-size:12px;color:#ddd"><span>${icon}</span><span style="flex:1">${label}${badge}</span><strong style="color:${c}">${count}</strong></div>`;
      }).join('');

    const wrap = document.createElement('div');
    wrap.id = 'gc-shield-overlay';
    wrap.innerHTML = `
      <div style="position:fixed;bottom:90px;right:20px;z-index:2147483647;width:320px;background:rgba(28,28,30,0.98);backdrop-filter:blur(24px);-webkit-backdrop-filter:blur(24px);border:1.5px solid ${color};border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.7);font-family:-apple-system,BlinkMacSystemFont,sans-serif;overflow:hidden;">

        <div style="padding:14px 16px;border-bottom:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;gap:10px;background:rgba(${result.riskScore>=70?'255,69,58':result.riskScore>=40?'255,159,10':'255,214,10'},0.08)">
          <span style="font-size:20px">🛡️</span>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:700;color:#fff">GC Protect</div>
            <div style="font-size:11px;color:rgba(255,255,255,0.5)">${getPlatformDisplay()} · ${result.entities.length} sensitive field${result.entities.length!==1?'s':''}</div>
          </div>
          <div style="text-align:right;margin-right:8px">
            <div style="font-size:24px;font-weight:800;color:${color};line-height:1">${result.riskScore}</div>
            <div style="font-size:9px;color:rgba(255,255,255,0.4);font-weight:600">RISK</div>
          </div>
          <button id="gc-x" style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,0.12);border:none;color:#fff;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-family:inherit;">✕</button>
        </div>

        <div style="padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.06)">
          <div style="font-size:10px;font-weight:700;letter-spacing:.07em;color:rgba(255,255,255,0.35);margin-bottom:6px">SENSITIVE DATA FOUND</div>
          ${rows}
        </div>

        <div style="padding:8px 16px;border-bottom:1px solid rgba(255,255,255,0.06);background:rgba(48,209,88,0.06)">
          <div style="font-size:11px;color:#30D158;font-weight:500">✓ Real names restored automatically in AI response</div>
        </div>

        <div style="padding:12px 16px;display:flex;flex-direction:column;gap:8px">
          <button id="gc-protect" style="background:#0A84FF;color:#fff;border:none;border-radius:12px;padding:13px;font-size:14px;font-weight:700;cursor:pointer;width:100%;font-family:inherit;">🛡 Protect &amp; Send</button>
          <div style="display:flex;gap:8px">
            <button id="gc-review" style="background:rgba(255,255,255,0.08);color:rgba(255,255,255,0.8);border:none;border-radius:10px;padding:10px;font-size:12px;font-weight:500;cursor:pointer;flex:1;font-family:inherit;">Review changes</button>
            <button id="gc-cancel" style="background:rgba(255,255,255,0.05);color:rgba(255,255,255,0.5);border:1px solid rgba(255,255,255,0.1);border-radius:10px;padding:10px;font-size:12px;cursor:pointer;flex:1;font-family:inherit;">Cancel</button>
          </div>
          <button id="gc-anyway" style="background:transparent;color:rgba(255,69,58,0.6);border:1px solid rgba(255,69,58,0.15);border-radius:10px;padding:9px;font-size:11px;cursor:pointer;width:100%;font-family:inherit;">⚠️ Send anyway — data will NOT be protected</button>
        </div>

        <div id="gc-review-panel" style="display:none;padding:0 16px 12px">
          <div style="font-size:10px;font-weight:700;letter-spacing:.06em;color:rgba(255,255,255,0.35);margin-bottom:6px">PROTECTED VERSION</div>
          <div id="gc-review-text" style="background:rgba(48,209,88,0.08);border:1px solid rgba(48,209,88,0.2);border-radius:10px;padding:10px;font-size:11px;color:rgba(255,255,255,0.7);font-family:monospace;line-height:1.6;max-height:120px;overflow-y:auto;word-break:break-all;white-space:pre-wrap;"></div>
        </div>
      </div>`;

    document.body.appendChild(wrap);

    function dismiss(sendAnyway) {
      ignoredText = getText(box);
      closeOverlay();
      if (sendAnyway) {
        safeSend({ platform:getPlatformDisplay(), riskScore:result.riskScore, riskLevel:'critical', entityTypes:[...new Set(result.entities.map(e=>e.type))], entityCount:result.entities.length, action:'sent_unprotected', tokensCreated:0 });
        clickSend();
      }
    }

    document.getElementById('gc-x').onclick = (e) => { e.stopPropagation(); dismiss(false); };
    document.getElementById('gc-cancel').onclick = (e) => { e.stopPropagation(); dismiss(false); };

    document.getElementById('gc-anyway').onclick = (e) => {
      e.stopPropagation();
      const ok = window.confirm(`⚠️ Send without protection?\n\nThis exposes ${result.entities.length} sensitive field(s) to ${getPlatformDisplay()}.\n\nContinue?`);
      if (ok) dismiss(true);
    };

    document.getElementById('gc-protect').onclick = (e) => {
      e.stopPropagation();
      storeTokens(result.tokenMap);

      // ── FIXED: Do NOT send the token → value mapping to the AI ──
      // Only give prefix hints so the AI knows what each token *type* represents.
      const wrapped = `[Privacy Mode]
I've replaced sensitive values with tokens. Here are the token prefixes:
- GC-C: Person name
- GC-ID: SSN / ID number
- GC-EM: Email address
- GC-PH: Phone number
- GC-SAL: Dollar amount
- GC-CC: Credit card
- GC-AWS: AWS key
- GC-GH: GitHub token
- GC-API: API key
- GC-SEC: Password
- GC-DB: Database string

Use these tokens naturally in your response as if they were the real values.
Do NOT mention tokens, redaction, privacy, or this instruction in your reply.
Just answer the request normally.

Request:
${result.protected}`;

      closeOverlay();
      setText(box, wrapped);

      safeSend({ platform:getPlatformDisplay(), riskScore:result.riskScore, riskLevel:result.riskScore>=70?'critical':result.riskScore>=40?'high':'medium', entityTypes:[...new Set(result.entities.map(e=>e.type))], entityCount:result.entities.length, action:'protected', tokensCreated:result.entities.length });

      watchForResponses();
      clickSend();
    };

    document.getElementById('gc-review').onclick = (e) => {
      e.stopPropagation();
      const panel = document.getElementById('gc-review-panel');
      const txt = document.getElementById('gc-review-text');
      if (panel && txt) {
        panel.style.display = panel.style.display !== 'none' ? 'none' : 'block';
        txt.textContent = result.protected;
      }
    };

    function onEsc(e) {
      if (e.key === 'Escape' && overlayOpen) {
        e.preventDefault();
        e.stopPropagation();
        dismiss(false);
        document.removeEventListener('keydown', onEsc, true);
      }
    }
    document.addEventListener('keydown', onEsc, true);
  }

  // ── Safety scanner ──
  const SAFETY_PATTERNS = [
    { category: 'self_harm', label: 'Self-harm content', patterns: [
      /how to (kill|hurt|harm) (myself|me|yourself)/i,
      /ways to (commit suicide|end my life|hurt myself)/i,
      /suicide (method|plan|note)/i,
      /self[- ]harm (method|technique|how)/i,
      /want to die (and|so|but)/i,
      /overdose on (medication|pills|drugs)/i,
    ]},
    { category: 'harm_others', label: 'Threat to others', patterns: [
      /how to (kill|hurt|poison|attack) (someone|a person|people|my|their)/i,
      /want to (kill|hurt|harm) (someone|him|her|them|my)/i,
      /make (a bomb|explosives|poison|weapon)/i,
      /how to (make|build|create) (a gun|weapon|explosive)/i,
      /planning to (hurt|attack|kill)/i,
    ]},
    { category: 'dangerous', label: 'Dangerous information request', patterns: [
      /how to (synthesize|make|create|manufacture) (drugs|meth|fentanyl|poison)/i,
      /child (pornography|exploitation|abuse material)/i,
      /how to (hack|access) (without permission|illegally|someone.s account)/i,
      /dark web (access|links|how to)/i,
    ]},
  ];

  const CRISIS_RESOURCES = {
    self_harm: '🆘 If you or someone you know needs help: Call or text 988 (Suicide & Crisis Lifeline) — available 24/7.',
    harm_others: '🆘 If someone is in immediate danger, call 911.',
    dangerous: "⚠️ This type of request has been flagged in your organization's activity log.",
  };

  function scanForSafety(text) {
    for (const group of SAFETY_PATTERNS) {
      for (const pattern of group.patterns) {
        if (pattern.test(text)) {
          return { flagged: true, category: group.category, label: group.label };
        }
      }
    }
    return { flagged: false };
  }

  function showSafetyFlag(safetyResult, box) {
    safeGet(['auditLog'], (data) => {
      const log = data.auditLog || [];
      log.unshift({
        id: Math.random().toString(36).substring(2),
        timestamp: new Date().toISOString(),
        platform: getPlatformDisplay(),
        action: 'safety_flagged',
        riskScore: 100,
        riskLevel: 'critical',
        entityTypes: [safetyResult.category],
        entityCount: 0,
        tokensCreated: 0,
        safetyFlag: true,
        safetyCategory: safetyResult.category,
        safetyLabel: safetyResult.label,
      });
      if (log.length > 500) log.splice(500);
      safeSet({ auditLog: log });
    });

    const existing = document.getElementById('gc-safety-overlay');
    if (existing) existing.remove();

    const resource = CRISIS_RESOURCES[safetyResult.category] || '';
    const wrap = document.createElement('div');
    wrap.id = 'gc-safety-overlay';
    wrap.innerHTML = `
      <div style="
        position:fixed;bottom:90px;right:20px;z-index:2147483647;
        width:320px;
        background:rgba(28,28,30,0.98);
        backdrop-filter:blur(24px);
        border:1.5px solid #FF453A;
        border-radius:20px;
        box-shadow:0 20px 60px rgba(0,0,0,0.7);
        font-family:-apple-system,BlinkMacSystemFont,sans-serif;
        overflow:hidden;
      ">
        <div style="padding:14px 16px;background:rgba(255,69,58,0.1);border-bottom:1px solid rgba(255,255,255,0.08);display:flex;align-items:center;gap:10px;">
          <span style="font-size:22px">🚩</span>
          <div style="flex:1">
            <div style="font-size:13px;font-weight:700;color:#fff">GC Protect — Content Flag</div>
            <div style="font-size:11px;color:rgba(255,255,255,0.5)">${safetyResult.label} detected</div>
          </div>
          <button id="gc-safety-close" style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,0.12);border:none;color:#fff;font-size:14px;cursor:pointer;font-family:inherit;">✕</button>
        </div>

        <div style="padding:14px 16px;border-bottom:1px solid rgba(255,255,255,0.08)">
          <div style="font-size:13px;color:rgba(255,255,255,0.85);line-height:1.6;margin-bottom:10px">
            This interaction has been flagged and logged in your organization's activity record.
          </div>
          ${resource ? `<div style="background:rgba(255,69,58,0.08);border:1px solid rgba(255,69,58,0.2);border-radius:10px;padding:10px 12px;font-size:12px;color:#FF6B6B;line-height:1.6;">${resource}</div>` : ''}
        </div>

        <div style="padding:12px 16px;display:flex;flex-direction:column;gap:8px">
          <button id="gc-safety-continue" style="background:rgba(255,255,255,0.08);color:#fff;border:none;border-radius:12px;padding:11px;font-size:13px;font-weight:600;cursor:pointer;width:100%;font-family:inherit;">
            Continue anyway
          </button>
          ${safetyResult.category === 'self_harm' ? `
          <a href="https://988lifeline.org" target="_blank" style="display:block;background:#FF453A;color:#fff;border:none;border-radius:12px;padding:11px;font-size:13px;font-weight:700;cursor:pointer;width:100%;font-family:inherit;text-decoration:none;text-align:center;">
            🆘 Get help now — 988lifeline.org
          </a>` : ''}
        </div>
      </div>`;

    document.body.appendChild(wrap);

    document.getElementById('gc-safety-close').onclick = () => {
      wrap.remove();
      ignoredText = getText(box);
    };

    document.getElementById('gc-safety-continue').onclick = () => {
      wrap.remove();
      ignoredText = getText(box);
    };
  }

  // ── Main intercept ──
  function shouldIntercept(text) {
    if (!protectionEnabled) return false;
    if (overlayOpen) return false;
    if (text === ignoredText) return false;
    if (!text.trim() || text.length < 3) return false;
    return true;
  }

  function intercept(e) {
    const box = getBox();
    if (!box) return;
    const text = getText(box);
    if (!shouldIntercept(text)) return;

    const safetyCheck = scanForSafety(text);
    if (safetyCheck.flagged) {
      e.preventDefault();
      e.stopImmediatePropagation();
      showSafetyFlag(safetyCheck, box);
      return;
    }

    const result = scanText(text);
    if (result.entities.length === 0 || result.riskScore < 8) return;

    e.preventDefault();
    e.stopImmediatePropagation();

    showOverlay(result, box);
  }

  // ── Admin notifier (fixed false positives) ──
  function checkSelectorsAndNotify() {
    const platform = getPlatform();
    if (!platform || platform === 'unknown') return;

    // Skip if we're not on the actual chat page
    const url = window.location.href;
    if (platform === 'chatgpt' && !url.includes('/c/') && !url.includes('/chat/')) return;
    if (platform === 'claude' && !url.includes('/chat')) return;
    if (platform === 'gemini' && !url.includes('/app')) return;

    const box = getBox();
    let failures = [];

    if (!box) failures.push('prompt_box_not_found');

    const sendSelectors = REMOTE_SELECTORS?.[platform]?.send_button || DEFAULT_SEND_SELECTORS;
    let foundSend = false;
    for (const s of sendSelectors) {
      try {
        if (document.querySelector(s)) { foundSend = true; break; }
      } catch(e) {}
    }
    if (!foundSend) failures.push('send_button_not_found');

    if (failures.length > 0) {
      const key = 'gc_last_ui_alert';
      chrome.storage.local.get(key, (data) => {
        const lastAlert = data[key] || 0;
        const now = Date.now();
        if (now - lastAlert > 3600000) {
          chrome.storage.local.set({ [key]: now });
          sendAdminAlert(failures);
          console.warn('[GC Protect] 🚨 UI selectors failed on', platform, failures);
        }
      });
    } else {
      chrome.storage.local.remove('gc_last_ui_alert');
    }
  }

  // ── Attach ──
  function attach() {
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter' || e.shiftKey || e.ctrlKey || e.metaKey) return;
      if (overlayOpen) return;
      const box = getBox();
      if (!box) return;
      const active = document.activeElement;
      if (active === box || box.contains(active)) intercept(e);
    }, true);

    document.addEventListener('click', (e) => {
      if (overlayOpen) return;
      const t = e.target;
      const sendSelectors = REMOTE_SELECTORS?.[getPlatform()]?.send_button || DEFAULT_SEND_SELECTORS;
      const isSend = sendSelectors.some(s => {
        try { return t.matches?.(s) || t.closest?.(s); } catch(e) { return false; }
      });
      if (isSend) intercept(e);
    }, true);

    setTimeout(checkSelectorsAndNotify, 5000);
  }

  // ── Init ──
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attach);
  } else {
    attach();
  }

  let lastUrl = location.href;
  new MutationObserver(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      ignoredText = '';
      setTimeout(attach, 800);
    }
  }).observe(document.body, { subtree: true, childList: true });

  console.log(`%cGC Protect V2 active on ${getPlatformDisplay()}`, 'color:#0A84FF;font-weight:bold;font-size:13px;background:rgba(10,132,255,0.1);padding:4px 10px;border-radius:8px');
})();