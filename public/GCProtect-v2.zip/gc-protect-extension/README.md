# GradiaCore Shield — Browser Extension

## What it does
Sits between employees and AI tools (ChatGPT, Claude, Gemini, Copilot).
Before any prompt is sent, it scans for sensitive data, shows a risk score,
and replaces real identities with secure GC tokens. The AI gets context.
The human behind the data stays protected.

---

## Install for development (load unpacked)

### Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2 — Install dependencies
```bash
npm install -g typescript
npm install -g esbuild
```

### Step 3 — Compile TypeScript files
```bash
# Compile content script
esbuild src/content/index.ts --bundle --outfile=content.js --format=esm --platform=browser

# Compile scanner lib (bundled into content.js above automatically)
```

### Step 4 — Load in Chrome
1. Open Chrome
2. Go to chrome://extensions
3. Enable "Developer mode" (top right toggle)
4. Click "Load unpacked"
5. Select this folder (gradiacore-ext)
6. Extension is live

### Step 5 — Test it
1. Go to https://chat.openai.com or https://claude.ai
2. Paste this into the prompt box:
   "Grace Robinson, SSN: 123-45-6789, salary $82,000, email grace@company.com"
3. Press Enter or click Send
4. GradiaCore overlay appears before it sends
5. Click "Protect & Send"
6. The protected version goes to the AI instead

---

## File structure

```
gradiacore-ext/
├── manifest.json          ← Chrome extension config
├── background.js          ← Service worker (audit logging)
├── popup.html             ← Extension popup UI
├── popup.js               ← Popup logic and stats
├── content.js             ← Built from src/content/index.ts
└── src/
    ├── content/
    │   └── index.ts       ← Main content script (intercept + UI)
    └── lib/
        ├── scanner.ts     ← PII detection + tokenization engine
        └── auditLog.ts    ← Audit log storage
```

---

## What's detected

| Type | Examples | Severity |
|------|----------|----------|
| SSN | 123-45-6789 | Critical |
| Credit card | 4111 1111 1111 1111 | Critical |
| API keys | sk-abc123... | Critical |
| Passwords | password: secret | Critical |
| Email | grace@company.com | High |
| Phone | (555) 123-4567 | High |
| Address | 123 Main St | High |
| Person name | Grace Robinson | High |
| Tax ID / EIN | 12-3456789 | High |
| Salary / payroll | $82,000/yr | Medium |
| Invoice numbers | INV-2938 | Medium |
| IP addresses | 192.168.1.1 | Medium |

---

## Token format

| Entity | Token example |
|--------|--------------|
| Client/Person | GC-CC8F2A |
| Email | GC-EMB291 |
| SSN | GC-ID9F82 |
| Bank account | GC-A1029F |
| API key | GC-KEY8B2 |
| Salary | GC-SAL291 |

---

## Revenue path

**Free tier:** Basic detection, 20 protections/month
**Pro $12/mo:** Unlimited, full audit log, custom rules
**Team $49/mo:** Up to 10 employees, admin dashboard, shared policies
**Business $149/mo:** Unlimited seats, compliance export, Slack alerts

---

## Next steps after V1

1. Add custom entity rules (admin defines company-specific sensitive terms)
2. Admin dashboard web app (Next.js) showing team-wide stats
3. Compliance report export (PDF showing what was protected)
4. Firefox and Edge support (same codebase, minor manifest changes)
5. API version for developers building their own AI tools
