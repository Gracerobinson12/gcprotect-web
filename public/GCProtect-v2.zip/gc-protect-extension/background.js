// GC Protect V2 — Background Service Worker
// Handles audit log, stats reporting, remote config, AND admin alerts

const CONFIG_URL = 'https://www.gcprotect.tech/config.json';
let remoteConfig = null;

// Fetch remote config on startup
async function loadConfig() {
  try {
    const res = await fetch(CONFIG_URL);
    remoteConfig = await res.json();
    await chrome.storage.local.set({ remoteConfig });
    console.log('[GC Protect] Config loaded:', remoteConfig.version);
  } catch (e) {
    // Fall back to cached config
    const cached = await chrome.storage.local.get('remoteConfig');
    if (cached.remoteConfig) remoteConfig = cached.remoteConfig;
  }
}

// Post protection event to Supabase
async function postEvent(payload) {
  if (!remoteConfig) {
    const cached = await chrome.storage.local.get('remoteConfig');
    remoteConfig = cached.remoteConfig;
  }
  if (!remoteConfig) return;

  const stored = await chrome.storage.local.get(['gc_user_id', 'gc_access_token']);
  if (!stored.gc_user_id || !stored.gc_access_token) return;

  try {
    await fetch(`${remoteConfig.supabase_url}/rest/v1/protection_events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': remoteConfig.anon_key,
        'Authorization': `Bearer ${stored.gc_access_token}`,
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify({
        user_id: stored.gc_user_id,
        platform: payload.platform,
        risk_score: payload.riskScore || 0,
        risk_level: payload.riskLevel || 'low',
        action: payload.action,
        entity_count: payload.entityCount || 0,
        entity_types: payload.entityTypes || [],
        tokens_created: payload.tokensCreated || 0,
        safety_flag: payload.action === 'safety_flagged',
        safety_category: payload.safetyCategory || null,
      }),
    });
  } catch (e) {
    // Silently fail — never block user
  }
}

// ── Admin alert: stores locally + sends to Supabase ──
async function postAdminAlert(payload) {
  if (!remoteConfig) {
    const cached = await chrome.storage.local.get('remoteConfig');
    remoteConfig = cached.remoteConfig;
  }

  // 1. Store locally first (always works)
  const alerts = await chrome.storage.local.get('adminAlerts');
  const list = alerts.adminAlerts || [];
  list.push({
    ...payload,
    timestamp: new Date().toISOString(),
    resolved: false,
  });
  if (list.length > 50) list.shift(); // Keep last 50
  await chrome.storage.local.set({ adminAlerts: list });
  console.warn('[GC Protect] 🚨 Admin alert stored locally:', payload);

  // 2. Try to send to Supabase (only if remote config exists and user is logged in)
  if (!remoteConfig) return;
  const stored = await chrome.storage.local.get(['gc_user_id', 'gc_access_token']);
  if (!stored.gc_user_id || !stored.gc_access_token) return;

  try {
    await fetch(`${remoteConfig.supabase_url}/rest/v1/admin_alerts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': remoteConfig.anon_key,
        'Authorization': `Bearer ${stored.gc_access_token}`,
        'Prefer': 'return=minimal',
      },
      body: JSON.stringify({
        user_id: stored.gc_user_id,
        alert_type: 'ui_failure',
        platform: payload.platform || 'unknown',
        failures: payload.failures || [],
        url: payload.url || '',
        user_agent: payload.userAgent || '',
        timestamp: new Date().toISOString(),
        resolved: false,
      }),
    });
    console.log('[GC Protect] ✅ Admin alert sent to Supabase');
  } catch (e) {
    // Silently fail — local storage copy is enough
  }
}

// Save to local audit log
async function saveToLog(payload) {
  const stored = await chrome.storage.local.get('auditLog');
  const log = stored.auditLog || [];
  log.unshift({
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    ...payload,
  });
  if (log.length > 500) log.splice(500);
  await chrome.storage.local.set({ auditLog: log });
}

// ── Message handler ──
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'LOG_INTERACTION') {
    saveToLog(message.payload);
    postEvent(message.payload);
  }
  else if (message.type === 'ADMIN_ALERT') {
    postAdminAlert(message.payload);
  }
  return true;
});

// Load config on install and startup
chrome.runtime.onInstalled.addListener(loadConfig);
chrome.runtime.onStartup.addListener(loadConfig);
loadConfig();